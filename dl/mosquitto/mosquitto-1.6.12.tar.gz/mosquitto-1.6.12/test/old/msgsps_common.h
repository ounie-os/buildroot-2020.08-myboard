#define HOST "127.0.0.1"
#define PORT 1888

#define PUB_QOS 1
#define SUB_QOS 1

#define MESSAGE_COUNT 100000L
#define MESSAGE_SIZE 1024L

