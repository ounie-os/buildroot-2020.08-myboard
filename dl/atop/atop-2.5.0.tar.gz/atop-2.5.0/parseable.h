int 	parsedef(char *);
char	parseout(time_t, int,
		struct devtstat *, struct sstat *,
		int, unsigned int, char);
