int f1 (int dummy)
{
  return 1;
}
