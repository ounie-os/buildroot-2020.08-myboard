extern int q1 (void);

int f1 (void)
{
  return q1 () + 1;
}

int q2 (void)
{
  return 9;
}
