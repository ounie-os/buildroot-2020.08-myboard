struct A
  {
    virtual int a();
    int b;
  };

int A::a()
{
  return 10;
}
